# FirdausApps
Aplikasi Muslim Basis Mobile Apps, dengan metode penentuan jadwal Sholat sesuai lokasi aplikasi dibuka,<br>
Perhitungan jadwal Sholat menggunakan metode Umm alQuro lunarcal<br>
Kalender Hijriyah dengan library calendar ummalqura-calendar<br>
berinteraksi dengan server menggunakan volley dan retroffit<br><br>
Base URL Quran https://quran-endpoint.vercel.app/quran/<br>
Base URL Hadits https://hadis-api-id.vercel.app/<br>
