package com.masterweb.firdausapps.azan.types;

/**
 * Created by AhmedEltaher on 11/11/16.
 */

public enum BaseTimeAdjustmentType {
    TWO_MINUTES_ADJUSTMENT,
    TWO_MINUTES_ZUHR
}
